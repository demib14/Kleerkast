# Kleerkast

Eerste testversie van de kleerkast-webapp.

Functies:
- kledingfoto’s toevoegen
- outfits samenstellen
- outfits bewaren
- twijfelstukken bewaren
